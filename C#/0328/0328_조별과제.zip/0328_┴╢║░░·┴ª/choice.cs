﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_조별과제
{   
    enum choice 
    { 
        NONE,
        MAKE,   //
        DEPOSIT,   //
        WITHDRAW, 
        INQUIRE, 
        EXIT 
    };
}
